# Detect_Tray_3 > 2024-06-03 7:40am
https://universe.roboflow.com/dataset-oti3p/detect_tray_3

Provided by a Roboflow user
License: CC BY 4.0

